#include <stdio.h>
#include <stdlib.h>
int main()
{
	printf("\n1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n\t");
	system ("PAUSE");
}
