#include <stdio.h> 
#include <stdlib.h> 
int main ()
{
	printf("\t Alexandre e Wendell \n");
	system("PAUSE");
}
